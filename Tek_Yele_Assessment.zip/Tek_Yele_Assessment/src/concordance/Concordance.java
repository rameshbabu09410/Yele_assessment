package concordance;


import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class Concordance {
	
	private final static String WORD_SEPERATOR=" ";

	//please provide path of input File
	public static void main(String[] args) throws IOException {
		String inputFilePath = "src/resources/input.txt";
		String text = new String(Files.readAllBytes(Paths.get(inputFilePath)));
		
		Map<String, List<Integer>> map = new TreeMap<String, List<Integer>>();
		int sentenceCount = 0;

		BreakIterator iterator = BreakIterator.getSentenceInstance(Locale.US);
		iterator.setText(text);

		int start = iterator.first();
		//BreakIterator.DONE = -1, when last boundary is reached
		for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
			String sentence = text.substring(start, end);
			sentenceCount++;
			for (String word : sentence.split(WORD_SEPERATOR)) {
				if(word.matches("i.e.")!= true)
				 word = word.toLowerCase().replaceAll("[^a-z]", "");
				if (map.containsKey(word)) {
					map.get(word).add(sentenceCount);
				} else {
					List<Integer> numbers = new ArrayList<Integer>();
					numbers.add(sentenceCount);
					map.put(word, numbers);
				}
			}
		}

		for (String word : map.keySet()) {
			List<Integer> numbers = map.get(word);
			int i = 0;
			System.out.printf("%-15s %s\n",word ," {" + numbers.size() + ":" +  numbers.toString().substring(1,numbers.toString().length()-1).replaceAll("\s","") + "}");
		}
	}
}
